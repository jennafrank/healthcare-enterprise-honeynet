"""
Unified honeynet dashboard server — port 9090
Serves unified_dashboard.html and merges stats from both nodes.

Endpoints:
  /                — unified dashboard UI
  /api/meridian    — proxies http://localhost:8080/api/stats
  /api/cascade     — proxies http://10.0.0.101:8080/api/stats
  /api/combined    — merges both + extra per-node data for the dashboard
"""

import json
import logging
import urllib.request
import urllib.error
from pathlib import Path
from flask import Flask, Response, jsonify
from flask_cors import CORS

CASCADE_IP   = "10.0.0.101"
CASCADE_BASE = f"http://{CASCADE_IP}:8080"
MERIDIAN_BASE = "http://localhost:8080"

TIMEOUT = 5  # seconds per upstream request

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger("unified")

app = Flask(__name__)
CORS(app)

DASHBOARD_HTML = Path(__file__).parent / "unified_dashboard.html"


def _fetch(url: str) -> dict:
    """GET *url*, return parsed JSON.  Returns {"error": msg} on any failure."""
    try:
        with urllib.request.urlopen(url, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.URLError as exc:
        logger.warning("Upstream unreachable %s: %s", url, exc.reason)
        return {"error": str(exc.reason)}
    except Exception as exc:
        logger.warning("Fetch failed %s: %s", url, exc)
        return {"error": str(exc)}


def _fetch_node(base: str) -> dict:
    """
    Fetch all dashboard data from a single node's API.
    Returns a dict with keys: stats, sessions, countries, credentials,
    services, hourly, mitre, high_interest, sophistication.
    Any failed sub-request is stored as None.
    """
    endpoints = {
        "stats":         f"{base}/api/stats",
        "sessions":      f"{base}/api/sessions?limit=30",
        "countries":     f"{base}/api/countries",
        "credentials":   f"{base}/api/credentials",
        "services":      f"{base}/api/services",
        "hourly":        f"{base}/api/hourly",
        "mitre":         f"{base}/api/mitre",
        "high_interest": f"{base}/api/high-interest",
        "sophistication":f"{base}/api/sophistication",
    }
    result = {}
    for key, url in endpoints.items():
        data = _fetch(url)
        # Propagate node-level error only on the stats key
        result[key] = data
    # If stats itself errored, mark the whole node as errored
    if "error" in (result.get("stats") or {}):
        result["error"] = result["stats"]["error"]
    return result


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if DASHBOARD_HTML.exists():
        return Response(DASHBOARD_HTML.read_text(encoding="utf-8"), mimetype="text/html")
    return Response("<h1>unified_dashboard.html not found</h1>", status=500, mimetype="text/html")


@app.route("/api/meridian")
def api_meridian():
    data = _fetch(f"{MERIDIAN_BASE}/api/stats")
    status = 502 if "error" in data else 200
    return jsonify(data), status


@app.route("/api/cascade")
def api_cascade():
    data = _fetch(f"{CASCADE_BASE}/api/stats")
    status = 502 if "error" in data else 200
    return jsonify(data), status


@app.route("/api/combined")
def api_combined():
    meridian = _fetch_node(MERIDIAN_BASE)
    cascade  = _fetch_node(CASCADE_BASE)
    return jsonify({"meridian": meridian, "cascade": cascade})


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger.info("Unified dashboard starting on port 9090")
    logger.info("  Meridian : %s", MERIDIAN_BASE)
    logger.info("  Cascade  : %s", CASCADE_BASE)
    logger.info("  HTML     : %s", DASHBOARD_HTML)
    app.run(host="0.0.0.0", port=9090, debug=False, threaded=True)

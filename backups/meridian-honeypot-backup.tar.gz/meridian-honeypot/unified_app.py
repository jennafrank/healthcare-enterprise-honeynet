"""Unified SOC dashboard — serves unified.html on port 9090."""
from flask import Flask, render_template
from flask_cors import CORS
from pathlib import Path

app = Flask(__name__, template_folder=str(Path(__file__).parent / 'dashboard' / 'templates'))
CORS(app)

@app.route('/')
def index():
    return render_template('unified.html')

def run(port=9090, host='0.0.0.0'):
    app.run(host=host, port=port, debug=False, use_reloader=False)

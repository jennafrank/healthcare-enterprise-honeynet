"""
Meridian HR Honeypot — Main Entry Point
Starts SSH (22), MySQL (3306), Redis (6379), MongoDB (27017) concurrently.
Dashboard on port 8080.
"""

import asyncio
import asyncssh
import logging
import os
import sys
import threading
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/app/logs/honeypot.log"),
    ]
)
logger = logging.getLogger("main")

from honeypot.db import DB
from honeypot.logger import HoneypotLogger
from honeypot.mysql_server import start_mysql_server
from honeypot.nosql_servers import start_redis_server, start_mongodb_server
from honeypot.ad_server import start_ldap_server, start_ldaps_server, start_gc_server, start_kerberos_server
from honeypot.smb_server import start_smb_server
from honeypot.mitre import tag_session, score_sophistication

# Config from environment
SSH_PORT     = int(os.environ.get("SSH_PORT", 22))
MYSQL_PORT   = int(os.environ.get("MYSQL_PORT", 3306))
REDIS_PORT   = int(os.environ.get("REDIS_PORT", 6379))
MONGO_PORT   = int(os.environ.get("MONGO_PORT", 27017))
LDAP_PORT    = int(os.environ.get("LDAP_PORT", 389))
LDAPS_PORT   = int(os.environ.get("LDAPS_PORT", 636))
GC_PORT      = int(os.environ.get("GC_PORT", 3268))
KERBEROS_PORT= int(os.environ.get("KERBEROS_PORT", 88))
SMB_PORT     = int(os.environ.get("SMB_PORT", 445))
DASHBOARD_PORT = int(os.environ.get("DASHBOARD_PORT", 8080))
HOST_KEY     = os.environ.get("HOST_KEY_PATH", "/app/data/ssh_host_key")
BIND_HOST    = os.environ.get("BIND_HOST", "0.0.0.0")


def generate_host_key():
    key_path = Path(HOST_KEY)
    if not key_path.exists():
        logger.info("Generating SSH host key...")
        key = asyncssh.generate_private_key("ssh-rsa", key_size=2048)
        key_path.parent.mkdir(parents=True, exist_ok=True)
        key.write_private_key(str(key_path))
        logger.info(f"Host key saved to {key_path}")
    return str(key_path)


def run_dashboard(db: DB):
    """Run Flask dashboard in its own thread."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from dashboard.app import app, db as dash_db
    # Share DB instance
    import dashboard.app as dash_module
    dash_module.db = db
    logger.info(f"[Dashboard] Starting on port {DASHBOARD_PORT}")
    app.run(host=BIND_HOST, port=DASHBOARD_PORT, debug=False, use_reloader=False)

def run_unified():
    """Run unified SOC dashboard on port 9090."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from unified_app import run as unified_run
    logger.info('[Unified] Starting on port 9090')
    unified_run(port=9090, host=BIND_HOST)



async def run_ssh_server(db: DB, hplogger: HoneypotLogger, host_key: str):
    """Run the SSH honeypot."""
    from honeypot.ssh_server import HoneypotSSHServer, HoneypotSession

    def server_factory():
        server = HoneypotSSHServer(db=db, hplogger=hplogger)
        return server

    class SessionFactory:
        def __init__(self, ssh_server):
            self._ssh_server = ssh_server

        def __call__(self):
            from honeypot.shell import FakeShell
            import asyncio
            return HoneypotShellProcess(
                ssh_server=self._ssh_server, db=db, hplogger=hplogger
            )

    await asyncssh.create_server(
        server_factory,
        BIND_HOST,
        SSH_PORT,
        server_host_keys=[host_key],
    )
    logger.info(f"[SSH] Honeypot listening on {BIND_HOST}:{SSH_PORT}")


class HoneypotShellProcess(asyncssh.SSHServerProcess):
    """Async process handler for SSH shell sessions."""

    def __init__(self, ssh_server, db, hplogger):
        super().__init__()
        self._hpdb = db
        self._hplogger = hplogger
        self._ssh_server = ssh_server
        self._shell = None

    async def run(self):
        from honeypot.shell import FakeShell
        server = self.channel.get_extra_info("server_object")
        session_id = getattr(server, "session_id", "unknown")
        username = getattr(server, "username", "unknown")
        peer_ip = getattr(server, "peer_ip", "unknown")

        self._shell = FakeShell(
            chan=self.stdout,
            session_id=session_id,
            username=username,
            db=self._hpdb,
            hplogger=self._hplogger,
        )

        import asyncio, random
        await asyncio.sleep(random.uniform(0.8, 2.0))
        self.stdout.write(self._shell.motd())
        self.stdout.write(self._shell.prompt())

        async for line in self.stdin:
            await self._shell.handle_input(line)
            self.stdout.write(self._shell.prompt())


async def main():
    logger.info("=" * 60)
    logger.info("  Meridian HR Solutions Honeypot — Starting")
    logger.info("  Services: SSH | MySQL | Redis | MongoDB | Dashboard")
    logger.info("=" * 60)

    # Init shared state
    db = DB()
    hplogger = HoneypotLogger()
    host_key = generate_host_key()

    # Start dashboard in background thread
    dash_thread = threading.Thread(target=run_dashboard, args=(db,), daemon=True)
    dash_thread.start()
    # Unified dashboard on port 9090
    unified_thread = threading.Thread(target=run_unified, daemon=True)
    unified_thread.start()

    # Start network services
    tasks = []

    # MySQL
    mysql_server = await start_mysql_server(BIND_HOST, MYSQL_PORT, db, hplogger)
    logger.info(f"[MySQL] Honeypot listening on {BIND_HOST}:{MYSQL_PORT}")

    # Redis
    redis_server = await start_redis_server(BIND_HOST, REDIS_PORT, db, hplogger)
    logger.info(f"[Redis] Honeypot listening on {BIND_HOST}:{REDIS_PORT}")

    # MongoDB
    mongo_server = await start_mongodb_server(BIND_HOST, MONGO_PORT, db, hplogger)
    logger.info(f"[MongoDB] Honeypot listening on {BIND_HOST}:{MONGO_PORT}")

    # Active Directory — LDAP (389), LDAPS (636), Global Catalog (3268), Kerberos (88)
    await start_ldap_server(BIND_HOST, LDAP_PORT, db, hplogger)
    await start_ldaps_server(BIND_HOST, LDAPS_PORT, db, hplogger)
    await start_gc_server(BIND_HOST, GC_PORT, db, hplogger)
    await start_kerberos_server(BIND_HOST, KERBEROS_PORT, db, hplogger)
    logger.info(f"[AD] LDAP:{LDAP_PORT} | LDAPS:{LDAPS_PORT} | GC:{GC_PORT} | Kerberos:{KERBEROS_PORT}")

    # SMB fake honeypot (port 445 — if real Samba is running, set SMB_PORT=4450)
    try:
        await start_smb_server(BIND_HOST, SMB_PORT, db, hplogger)
        logger.info(f"[SMB] Honeypot listening on {BIND_HOST}:{SMB_PORT}")
    except OSError as e:
        logger.warning(f"[SMB] Port {SMB_PORT} unavailable ({e}) — real Samba may own this port (OK)")

    # SSH (asyncssh has its own async server model)
    try:
        ssh_server = await asyncssh.create_server(
            lambda: _make_ssh_server(db, hplogger),
            BIND_HOST, SSH_PORT,
            server_host_keys=[host_key],
            process_factory=lambda process: _handle_ssh_process(process, db, hplogger),
        )
        logger.info(f"[SSH] Honeypot listening on {BIND_HOST}:{SSH_PORT}")
    except Exception as e:
        logger.warning(f"[SSH] Could not bind port {SSH_PORT}: {e} — try running as root or with CAP_NET_BIND_SERVICE")

    logger.info(f"[Dashboard] http://{BIND_HOST}:{DASHBOARD_PORT}")
    logger.info("All services running. Waiting for attackers...")

    # Keep alive
    await asyncio.Event().wait()


def _make_ssh_server(db, hplogger):
    from honeypot.ssh_server import HoneypotSSHServer
    return HoneypotSSHServer(db=db, hplogger=hplogger)


async def _handle_ssh_process(process, db, hplogger):
    from honeypot.shell import FakeShell
    import random

    server = process.channel.get_extra_info("server_object") if hasattr(process.channel, "get_extra_info") else None
    session_id = getattr(server, "session_id", "local_session")
    username = getattr(server, "username", process.get_extra_info("username", "user"))
    peer_ip = getattr(server, "peer_ip", "0.0.0.0")

    shell = FakeShell(
        chan=process.stdout,
        session_id=session_id,
        username=username,
        db=db,
        hplogger=hplogger,
    )

    await asyncio.sleep(random.uniform(0.8, 1.8))
    process.stdout.write(shell.motd())
    process.stdout.write(shell.prompt())

    try:
        async for line in process.stdin:
            if line:
                await shell.handle_input(line)
                if not process.stdin.at_eof():
                    process.stdout.write(shell.prompt())
    except Exception:
        pass

    process.exit(0)


if __name__ == "__main__":
    asyncio.run(main())

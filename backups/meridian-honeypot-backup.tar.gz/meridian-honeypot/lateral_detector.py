#!/usr/bin/env python3
"""
lateral_detector.py — Cross-node lateral movement detector.

Watches this node's JSONL event log and compares attacker IPs against
peer nodes. Fires a LATERAL_MOVEMENT alert when the same IP appears on
multiple nodes.

Usage:
    python3 lateral_detector.py \
        --node meridian \
        --my-log /app/logs/events.jsonl \
        [--peer-log cascade:/app/logs/peers/cascade/events.jsonl] \
        [--peer-ssh cascade:user@10.0.0.101:/app/logs/events.jsonl] \
        [--out /app/logs/lateral_movement.jsonl] \
        [--interval 10]

Peer auto-discovery:
    Drop a peer's JSONL log at /app/logs/peers/<node_name>/events.jsonl
    and it will be picked up automatically on the next poll cycle.
"""

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

try:
    import asyncssh
    HAS_ASYNCSSH = True
except ImportError:
    HAS_ASYNCSSH = False

# Fields to check when extracting an attacker IP from a JSONL event.
IP_FIELDS = (
    "src_ip", "source_ip", "remote_ip", "attacker_ip",
    "client_ip", "peer_ip", "ip", "address", "host",
)

DEFAULT_OUT      = "/app/logs/lateral_movement.jsonl"
DEFAULT_INTERVAL = 10   # seconds between poll cycles
PEER_DIR         = "/app/logs/peers"


# ── helpers ───────────────────────────────────────────────────────────────────

def extract_ip(event: dict) -> Optional[str]:
    for field in IP_FIELDS:
        val = event.get(field)
        if val and isinstance(val, str) and val not in ("", "0.0.0.0"):
            return val
    return None


def read_new_lines(path: str, pos: int) -> tuple:
    """Return (new_lines, new_pos). Handles log rotation (size < pos)."""
    try:
        size = os.path.getsize(path)
    except FileNotFoundError:
        return [], pos
    if size < pos:          # rotated
        pos = 0
    if size == pos:
        return [], pos
    try:
        with open(path, "r", errors="replace") as fh:
            fh.seek(pos)
            lines = fh.readlines()
            return lines, fh.tell()
    except OSError:
        return [], pos


def parse_events(lines: list) -> list:
    """Parse JSONL lines → [(ip, event_dict), ...]."""
    out = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        ip = extract_ip(event)
        if ip:
            out.append((ip, event))
    return out


async def ssh_read(host: str, path: str, pos: int, user: Optional[str],
                   port: int = 22) -> tuple:
    """Fetch bytes from `pos` onward from a remote file over SSH."""
    if not HAS_ASYNCSSH:
        return [], pos
    try:
        opts = {"host": host, "port": port, "known_hosts": None}
        if user:
            opts["username"] = user
        async with asyncssh.connect(**opts) as conn:
            # tail -c +N reads from byte N (1-based)
            res = await conn.run(
                f"tail -c +{pos + 1} {path} 2>/dev/null || true",
                check=False,
            )
            raw = res.stdout or ""
            lines = raw.splitlines(keepends=True)
            return lines, pos + len(raw.encode())
    except Exception as exc:
        _log(f"[SSH] {host}:{path}: {exc}")
        return [], pos


def _log(msg: str):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"{ts}  {msg}", flush=True)


# ── alert writer ──────────────────────────────────────────────────────────────

def write_alert(out_path: str, local_node: str, peer_node: str,
                ip: str, local_event: dict, peer_event: dict):
    alert = {
        "timestamp":    datetime.now(timezone.utc).isoformat(),
        "alert_type":   "LATERAL_MOVEMENT",
        "severity":     "HIGH",
        "attacker_ip":  ip,
        "nodes_seen":   [local_node, peer_node],
        "description": (
            f"IP {ip} observed on both '{local_node}' and '{peer_node}' — "
            "possible lateral movement between nodes"
        ),
        "local_node":   local_node,
        "local_event":  local_event,
        "peer_node":    peer_node,
        "peer_event":   peer_event,
    }
    _log(
        f"[!!!] LATERAL MOVEMENT — {ip} seen on '{local_node}' AND '{peer_node}'"
    )
    with open(out_path, "a") as fh:
        fh.write(json.dumps(alert) + "\n")


# ── detector ──────────────────────────────────────────────────────────────────

class LateralDetector:
    def __init__(self, node: str, my_log: str, out: str, interval: int):
        self.node     = node
        self.my_log   = my_log
        self.out      = out
        self.interval = interval

        self.my_pos:  int  = 0
        self.my_ips:  dict = {}   # ip → first event seen locally

        # peers[name] = {mode, path, [host, user], pos, ips}
        self.peers:   dict = {}

        # (ip, peer_name) pairs already alerted — suppress duplicates
        self.alerted: set  = set()

    def add_peer_local(self, name: str, path: str):
        if name not in self.peers:
            _log(f"[*] Peer registered (local): {name} → {path}")
        self.peers[name] = {"mode": "local", "path": path, "pos": 0, "ips": {}}

    def add_peer_ssh(self, name: str, host: str, path: str,
                     user: Optional[str], port: int = 22):
        if name not in self.peers:
            _log(f"[*] Peer registered (SSH): {name} → "
                 f"{user+'@' if user else ''}{host}:{port}:{path}")
        self.peers[name] = {
            "mode": "ssh", "host": host, "path": path,
            "user": user, "port": port, "pos": 0, "ips": {},
        }

    def _auto_discover(self):
        """Pick up peer logs dropped into PEER_DIR/<node>/events.jsonl."""
        base = Path(PEER_DIR)
        if not base.exists():
            return
        for node_dir in base.iterdir():
            name = node_dir.name
            if not node_dir.is_dir() or name == self.node or name in self.peers:
                continue
            candidate = node_dir / "events.jsonl"
            if candidate.exists():
                self.add_peer_local(name, str(candidate))

    def _maybe_alert(self, ip: str, peer_name: str,
                     local_event: dict, peer_event: dict):
        key = (ip, peer_name)
        if key not in self.alerted:
            self.alerted.add(key)
            write_alert(self.out, self.node, peer_name,
                        ip, local_event, peer_event)

    async def _poll_my_log(self):
        lines, self.my_pos = read_new_lines(self.my_log, self.my_pos)
        for ip, event in parse_events(lines):
            is_new = ip not in self.my_ips
            if is_new:
                self.my_ips[ip] = event
                _log(f"[{self.node}] attacker IP: {ip}  (event: {event.get('event_type', '?')})")
            # Check against every peer regardless of whether IP is new —
            # the peer set may have grown since we last saw this IP.
            for peer_name, peer in self.peers.items():
                if ip in peer["ips"]:
                    self._maybe_alert(ip, peer_name, event, peer["ips"][ip])

    async def _poll_peer(self, name: str, peer: dict):
        if peer["mode"] == "local":
            lines, peer["pos"] = read_new_lines(peer["path"], peer["pos"])
        else:
            lines, peer["pos"] = await ssh_read(
                peer["host"], peer["path"], peer["pos"],
                peer.get("user"), peer.get("port", 22)
            )
        for ip, event in parse_events(lines):
            if ip not in peer["ips"]:
                peer["ips"][ip] = event
                _log(f"[{name}] attacker IP: {ip}  (event: {event.get('event_type', '?')})")
            # Also check if this peer IP is already in our local log.
            if ip in self.my_ips:
                self._maybe_alert(ip, name, self.my_ips[ip], event)

    async def run(self):
        Path(self.out).parent.mkdir(parents=True, exist_ok=True)
        _log(f"[*] Starting — node={self.node}  log={self.my_log}")
        _log(f"[*] Alert output: {self.out}")
        _log(f"[*] Poll interval: {self.interval}s")
        _log(f"[*] Peer auto-discovery: {PEER_DIR}/<node>/events.jsonl")
        if not self.peers:
            _log("[*] No peers configured yet — waiting for auto-discovery or --peer-* args")

        while True:
            self._auto_discover()
            await self._poll_my_log()
            for name, peer in list(self.peers.items()):
                await self._poll_peer(name, peer)
            await asyncio.sleep(self.interval)


# ── entry point ───────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Cross-node lateral movement detector for honeypot clusters"
    )
    ap.add_argument("--node",      required=True,
                    help="Name for this node (e.g. 'meridian')")
    ap.add_argument("--my-log",    required=True,
                    help="Path to this node's JSONL event log")
    ap.add_argument("--peer-log",  action="append", default=[],
                    metavar="NAME:PATH",
                    help="Local peer log (repeatable): e.g. cascade:/app/logs/peers/cascade/events.jsonl")
    ap.add_argument("--peer-ssh",  action="append", default=[],
                    metavar="NAME:[USER@]HOST[:PORT]:PATH",
                    help="SSH peer log (repeatable): e.g. cascade:user@10.0.0.101:2223:/app/logs/events.jsonl")
    ap.add_argument("--out",       default=DEFAULT_OUT,
                    help=f"Alert output file (default: {DEFAULT_OUT})")
    ap.add_argument("--interval",  type=int, default=DEFAULT_INTERVAL,
                    help=f"Poll interval in seconds (default: {DEFAULT_INTERVAL})")
    args = ap.parse_args()

    detector = LateralDetector(
        node=args.node,
        my_log=args.my_log,
        out=args.out,
        interval=args.interval,
    )

    for spec in args.peer_log:
        parts = spec.split(":", 1)
        if len(parts) != 2:
            print(f"[!] Bad --peer-log '{spec}' — expected NAME:PATH", file=sys.stderr)
            sys.exit(1)
        detector.add_peer_local(parts[0], parts[1])

    for spec in args.peer_ssh:
        # Formats:
        #   NAME:[USER@]HOST:PATH
        #   NAME:[USER@]HOST:PORT:PATH
        parts = spec.split(":", 3)
        if len(parts) < 3:
            print(f"[!] Bad --peer-ssh '{spec}' — expected NAME:[USER@]HOST[:PORT]:PATH",
                  file=sys.stderr)
            sys.exit(1)
        name, host_spec = parts[0], parts[1]
        # Determine if parts[2] is a port (all digits) or the start of a path
        if len(parts) == 4:
            # NAME:host_spec:PORT:PATH
            try:
                port = int(parts[2])
                path = parts[3]
            except ValueError:
                print(f"[!] Bad port in --peer-ssh '{spec}'", file=sys.stderr)
                sys.exit(1)
        else:
            port = 22
            path = parts[2]
        if "@" in host_spec:
            user, host = host_spec.split("@", 1)
        else:
            user, host = None, host_spec
        detector.add_peer_ssh(name, host, path, user, port)

    asyncio.run(detector.run())


if __name__ == "__main__":
    main()

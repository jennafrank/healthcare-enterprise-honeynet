# 🍯 Meridian HR Solutions Honeypot

Multi-service honeypot posing as a corporate HR/payroll backend.
Built for SOC observation — no Easter eggs, pure threat intelligence.

## What It Does

Exposes four services Josh Madakor recommended as high-value attacker bait:

| Service | Port | Persona |
|---------|------|---------|
| SSH | 22 | Ubuntu admin server — `meridian-hrprod-01` |
| MySQL | 3306 | HR database — employees, payroll, SSNs, user hashes |
| Redis | 6379 | Session cache — JWT tokens, API keys, passwords in env |
| MongoDB | 27017 | Document store — W-2s, contracts, API keys |

Dashboard on port 8080 with 11 tracking modules.

## Threat Intelligence Collected

- Every credential attempt (username + password/hash) across all four services
- Every command typed in SSH
- Every MySQL query, Redis command, MongoDB operation
- GeoIP: country, city, ISP, ASN, cloud vs residential
- AbuseIPDB reputation score
- MITRE ATT&CK auto-tagging (50+ rules across all four services)
- Attacker sophistication score (1–10)
- High-interest flagging: credential harvests, lateral movement, IMDS probes, destructive commands

## Deploy on Azure

### 1. Move your real SSH first
```bash
# Edit /etc/ssh/sshd_config — change Port to 2223
sudo sed -i 's/#Port 22/Port 2223/' /etc/ssh/sshd_config
sudo systemctl restart sshd
# Open port 2223 in your Azure NSG, verify you can still connect
```

### 2. Open the honeypot ports in Azure NSG
In your Network Security Group, add inbound rules for:
- TCP 22 (SSH)
- TCP 3306 (MySQL)
- TCP 6379 (Redis)
- TCP 27017 (MongoDB)
- TCP 8080 (Dashboard — restrict to your IP only)

### 3. Clone and deploy
```bash
git clone https://github.com/YOUR_USERNAME/meridian-honeypot
cd meridian-honeypot

# Optional: set your AbuseIPDB key for reputation scoring
echo "ABUSEIPDB_API_KEY=your_key_here" > .env

docker compose up -d
```

### 4. View dashboard
```
http://YOUR_VM_IP:8080
```

### 5. Watch the logs
```bash
docker compose logs -f
tail -f logs/events.jsonl | python3 -m json.tool
```

## Dashboard Modules

1. **Key Stats** — sessions, auth successes, high-interest count, credential attempts
2. **Attack Origin Map** — live Leaflet world map, color-coded by service
3. **Live Event Feed** — real-time SSE stream of every connection and command
4. **Service Breakdown** — doughnut chart showing SSH vs MySQL vs Redis vs MongoDB share
5. **Top Countries** — bar chart of attacker origin nations
6. **Hourly Attack Volume** — 24-hour rolling line chart
7. **Attacker Sophistication** — distribution of 1–10 scores
8. **Top Credential Attempts** — username/password pairs by frequency
9. **Top ASNs** — network providers with cloud/residential classification
10. **MITRE ATT&CK Summary** — all triggered techniques with hit counts
11. **High-Interest Sessions** — expandable profiles with full command logs + MITRE tags

## What Counts as High-Interest

Sessions are flagged automatically when an attacker:
- Reads `db.conf` (database credentials)
- Runs `env`/`printenv` (environment variables contain credentials)
- Reads `notes.txt` (SFTP credentials in fake notes)
- Queries MySQL `users` or `ssn_records` tables
- Accesses MongoDB `api_keys` or `w2_documents` collections
- Runs Redis `KEYS *` and then `GET auth:jwt_secret`
- Attempts Redis `CONFIG SET` or `SLAVEOF` (RCE vector)
- Probes `169.254.169.254` (Azure IMDS endpoint)
- Uses `export HISTFILE=/dev/null` (anti-forensics)
- Attempts `su`, `sudo su`, `useradd`, `ssh-keygen` (escalation/persistence)
- Runs `nc`, uses `/dev/tcp/`, or `wget`/`curl` to download tools

## MITRE ATT&CK Coverage

The tagger covers techniques across all four services:

- **T1110** Brute Force
- **T1003** OS Credential Dumping
- **T1552** Credentials in Files
- **T1046** Network Service Discovery
- **T1049** System Network Connections Discovery
- **T1057** Process Discovery
- **T1083** File and Directory Discovery
- **T1082** System Information Discovery
- **T1021** Remote Services (lateral movement via SSH)
- **T1053** Scheduled Task (cron persistence)
- **T1098** SSH Authorized Keys (persistence)
- **T1105** Ingress Tool Transfer (wget/curl)
- **T1048** Exfiltration Over Alternative Protocol
- **T1485** Data Destruction (DROP, FLUSHALL, rm -rf)
- **T1190** Exploit Public-Facing Application (MySQL file RCE, Redis replication)
- **T1552.005** Cloud Instance Metadata API (IMDS probe)
- **T1070** Indicator Removal (history clear)
- **T1548** Abuse Elevation Control Mechanism (sudo/su)
...and 30+ more

## Project Structure

```
meridian-honeypot/
├── main.py                    # Entry point — starts all services
├── honeypot/
│   ├── ssh_server.py          # asyncssh honeypot server
│   ├── shell.py               # FakeShell — 60+ commands, corporate persona
│   ├── mysql_server.py        # MySQL wire protocol honeypot
│   ├── nosql_servers.py       # Redis + MongoDB honeypots
│   ├── mitre.py               # ATT&CK auto-tagger + sophistication scorer
│   ├── db.py                  # SQLite WAL-mode database layer
│   ├── enrichment.py          # GeoIP + AbuseIPDB + rDNS
│   └── logger.py              # JSONL event logger
├── dashboard/
│   ├── app.py                 # Flask + SSE dashboard
│   └── templates/index.html   # 11-module dashboard UI
├── data/                      # SQLite DB + SSH host key (gitignored)
├── logs/                      # JSONL events + honeypot.log (gitignored)
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

## Legal

This is a honeypot for observation of unsolicited attack traffic against your own Azure infrastructure.
Only deploy against resources you own and control.
Check your organization's policies before deploying.

#!/bin/bash
# ============================================================
# MySQL General Query Log Setup — Meridian Honeypot
# Enables MySQL's built-in logging alongside honeypot capture
# Run this if you deploy a REAL MySQL instance instead of
# (or alongside) the Python honeypot server
# ============================================================

echo "========================================================"
echo " MySQL General Query Log Setup"
echo "========================================================"

# ─── MySQL Config ─────────────────────────────────────────────────────────────
# Add to /etc/mysql/mysql.conf.d/mysqld.cnf

MYSQL_CONF="/etc/mysql/mysql.conf.d/mysqld.cnf"

if [ ! -f "$MYSQL_CONF" ]; then
    echo "[!] MySQL config not found at $MYSQL_CONF"
    echo "    Adjust path for your installation."
    exit 1
fi

echo "[*] Enabling general query log in MySQL config..."
cat >> "$MYSQL_CONF" << 'EOF'

# ── Meridian Honeypot: Full Query Logging ──────────────────
# General query log — every query from every client
general_log = ON
general_log_file = /var/log/mysql/general.log

# Slow query log — anything over 0 seconds (catches everything)
slow_query_log = ON
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 0
log_queries_not_using_indexes = ON

# Binary log (for change tracking)
log_bin = /var/log/mysql/mysql-bin
binlog_format = STATEMENT
expire_logs_days = 30

# Connection logging
log_error = /var/log/mysql/error.log

# Performance schema for deep query analytics
performance_schema = ON
EOF

echo "[*] Restarting MySQL..."
systemctl restart mysql
sleep 2

echo "[*] Verifying logging is active..."
mysql -e "SHOW VARIABLES LIKE 'general_log%';"
mysql -e "SHOW VARIABLES LIKE 'slow_query%';"

echo ""
echo "========================================================"
echo " MySQL query logging enabled."
echo " Logs at: /var/log/mysql/general.log"
echo "========================================================"

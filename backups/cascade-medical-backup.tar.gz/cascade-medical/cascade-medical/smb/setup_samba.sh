#!/bin/bash
# ============================================================
# Meridian HR Solutions — Real Samba Honeypot Setup
# Installs actual Samba shares: HR, Finance, Backups
# Run on your Azure Linux VM (Ubuntu 22.04)
# ============================================================
set -e

echo "========================================================"
echo " Meridian Samba Honeypot — Setup Script"
echo "========================================================"

# ─── Install ──────────────────────────────────────────────────────────────────
echo "[*] Installing Samba..."
apt-get update -qq
apt-get install -y samba samba-common-bin auditd python3-pip

pip3 install watchdog --quiet  # For log monitoring

# ─── Create Share Directories ─────────────────────────────────────────────────
echo "[*] Creating share directories..."
mkdir -p /srv/samba/Clinical
mkdir -p /srv/samba/Finance
mkdir -p /srv/samba/Backups

chmod -R 0775 /srv/samba/
chown -R nobody:nogroup /srv/samba/

# ─── Populate Fake Files ──────────────────────────────────────────────────────
echo "[*] Populating fake files..."

# HR share
cat > /srv/samba/Clinical/Employee_Directory_2024.csv << 'EOF'
Employee_ID,First_Name,Last_Name,Email,Title,Department,Manager,Hire_Date,Salary,Status
1001,John,Smith,j.smith@meridianhr.com,Director of HR,Human Resources,CEO,2019-03-14,142500,Active
1002,Amanda,Torres,a.torres@meridianhr.com,Payroll Manager,Payroll,John Smith,2020-07-01,98000,Active
1003,Kevin,Park,k.park@meridianhr.com,Systems Administrator,IT,John Smith,2021-01-10,112000,Active
1004,Lisa,Chen,l.chen@meridianhr.com,Benefits Coordinator,Human Resources,John Smith,2022-04-22,74000,Active
1005,Marcus,Williams,m.williams@meridianhr.com,HRIS Analyst,IT,Kevin Park,2020-11-30,88000,Active
1006,Sarah,Johnson,s.johnson@meridianhr.com,Recruiter,Human Resources,John Smith,2023-02-14,67000,Active
1007,David,Lee,d.lee@meridianhr.com,Payroll Analyst,Payroll,Amanda Torres,2022-08-01,72000,Active
1008,Rachel,Kim,r.kim@meridianhr.com,HR Generalist,Human Resources,John Smith,2021-06-15,71000,Active
EOF

cat > /srv/samba/Clinical/Salary_Bands_2024_CONFIDENTIAL.csv << 'EOF'
Level,Title,Band_Min,Band_Mid,Band_Max,Notes
L1,Analyst I,55000,62000,72000,Entry level
L2,Analyst II,68000,77000,89000,2+ years experience
L3,Senior Analyst,85000,98000,115000,5+ years
L4,Manager,105000,122000,145000,People manager
L5,Senior Manager,130000,152000,178000,Multiple teams
L6,Director,165000,194000,225000,Department head
L7,VP,200000,245000,310000,Executive
EOF

cat > /srv/samba/Clinical/Termination_Checklist.txt << 'EOF'
MERIDIAN HR — Employee Termination Checklist
=============================================
[ ] Notify IT to disable AD account (same day)
[ ] Revoke VPN access
[ ] Collect company equipment
[ ] Disable email forwarding
[ ] Remove from payroll system
[ ] Final paycheck processed
[ ] Benefits termination notice sent
[ ] Exit interview completed
[ ] HRIS updated

Note: AD account disable done via: Disable-ADAccount -Identity <username>
IT emergency contact: k.park@meridianhr.com | Ext 4481
EOF

cat > /srv/samba/Clinical/New_Hire_IT_Request.txt << 'EOF'
New Hire IT Setup Request
=========================
Please provision the following for new employees:

1. AD Account (use template: hradmin@meridianhr.com)
   - Default password: Meridian2024! (must change on first login)
   - Add to group: Domain-Users, dept-specific group

2. Email: Exchange/O365
   - License: E3

3. VPN: FortiClient
   - Server: vpn.meridianhr.internal
   - Auth: AD credentials

4. Systems access (per manager approval):
   - HRIS: manager submits ticket to hris-access@meridianhr.com
   - Payroll: payroll manager approval required

Note: Shared admin account for emergencies: hradmin / Hr@dm1n2024!
(This needs to be rotated — Kevin flagged this in March)
EOF

# Finance share
cat > /srv/samba/Finance/Payroll_May2024_Summary.csv << 'EOF'
Employee_ID,Name,Gross_Pay,Federal_Tax,State_Tax,FICA,Net_Pay,Bank,Account_Last4,Pay_Date
1001,John Smith,11875.00,2672.81,593.75,908.44,7699.00,Chase,3847,2024-05-31
1002,Amanda Torres,8166.67,1837.50,408.33,624.75,5295.09,BofA,9920,2024-05-31
1003,Kevin Park,9333.33,2100.00,466.67,713.99,6052.67,Wells Fargo,1104,2024-05-31
1004,Lisa Chen,6166.67,1387.50,308.33,471.75,4003.09,Chase,5521,2024-05-31
1005,Marcus Williams,7333.33,1650.00,366.67,560.99,4755.67,BofA,8847,2024-05-31
EOF

cat > /srv/samba/Finance/Direct_Deposit_Accounts.txt << 'EOF'
MERIDIAN HR — Direct Deposit Account Registry
==============================================
CONFIDENTIAL — Finance Dept Use Only

Employee     Bank               Routing        Account        Type
-----------  -----------------  -------------  -------------  --------
J. Smith     Chase              021000021      ****3847       Checking
A. Torres    Bank of America    026009593      ****9920       Checking
K. Park      Wells Fargo        121000248      ****1104       Checking
L. Chen      Chase              021000021      ****5521       Checking
M. Williams  Bank of America    026009593      ****8847       Checking

Last updated: 2024-06-01 by Amanda Torres
ADP Integration: svc_payroll@meridianhr.local
ADP API Key: ADP-LIVE-b8f2c4e1-FAKE-KEY-PLACEHOLDER
EOF

cat > /srv/samba/Finance/Budget_FY2024_Notes.txt << 'EOF'
FY2024 Budget Notes — Internal Only
=====================================
Q1 Actual vs Budget: +3.2% variance (under budget)
Q2 Forecast: HR software renewal + 2 new hires (analyst level)

Vendor Passwords (for controller reference):
- ADP portal: adp.com | hradmin@meridianhr.com | ADP_Mer1d!an24
- Gusto backup: gusto.com | finance@meridianhr.com | Gust0_Fin@nce24

Bank contact: JPMorgan treasury line — 1-800-555-4821 ext 224
Account manager: Michael Torres | mtorres@jpmorgan.com
EOF

# Backups share
cat > /srv/samba/Backups/README.txt << 'EOF'
MERIDIAN HR — Backup Repository
================================
Contents:
  meridian_hr_db_YYYYMMDD.sql.gz  — Nightly MySQL dump (meridian_hr database)
  config_backup_YYYYMMDD.tar.gz   — Server config files
  redis_dump_YYYYMMDD.rdb         — Redis snapshot

Backup schedule: 02:00 UTC daily (cron on meridian-hrprod-01)
Retention: 30 days

Restore procedure:
  zcat meridian_hr_db_YYYYMMDD.sql.gz | mysql -u root -p meridian_hr

DB credentials for restore: see /opt/meridian/config/db.conf on hrprod-01
Or contact: k.park@meridianhr.com
EOF

# Create fake (empty but named) backup files so they show up in directory listings
touch /srv/samba/Backups/meridian_hr_db_20240603.sql.gz
touch /srv/samba/Backups/meridian_hr_db_20240602.sql.gz
touch /srv/samba/Backups/meridian_hr_db_20240601.sql.gz
touch /srv/samba/Backups/config_backup_20240603.tar.gz
touch /srv/samba/Backups/redis_dump_20240603.rdb

echo "[*] Fake files created."

# ─── Samba Configuration ──────────────────────────────────────────────────────
echo "[*] Writing smb.conf..."
cat > /etc/samba/smb.conf << 'SMBCONF'
[global]
   workgroup = MERIDIANHR
   server string = Meridian HR File Server
   netbios name = MERIDIAN-FS01
   security = user
   map to guest = bad user
   dns proxy = no
   server role = standalone server

   # Full logging — every access, every command
   log file = /var/log/samba/smb_%m.log
   max log size = 50000
   log level = 2 passdb:5 auth:5 winbind:5
   
   # Detailed audit logging
   vfs objects = full_audit
   full_audit:prefix = %u|%I|%S
   full_audit:success = connect disconnect opendir mkdir rmdir open read write rename unlink
   full_audit:failure = connect open
   full_audit:facility = local5
   full_audit:priority = notice

   # Force plaintext so we can read passwords (honeypot only — never do this in prod)
   client plaintext auth = yes
   ntlm auth = yes
   lanman auth = yes

[Clinical]
   comment = Human Resources — Meridian HR
   path = /srv/samba/Clinical
   browseable = yes
   read only = no
   guest ok = yes
   create mask = 0664
   directory mask = 0775

[Pharmacy]
   comment = Finance Department — Meridian HR
   path = /srv/samba/Pharmacy
   browseable = yes
   read only = no
   guest ok = yes
   create mask = 0664
   directory mask = 0775

[Backups]
   comment = Backup Repository — Meridian HR
   path = /srv/samba/Backups
   browseable = yes
   read only = no
   guest ok = yes
   create mask = 0664
   directory mask = 0775
SMBCONF

echo "[*] Configuring auditd for Samba access logging..."
cat >> /etc/audit/audit.rules << 'AUDITRULES'
# Samba share access audit
-w /srv/samba/Clinical -p rwxa -k smb_hr_access
-w /srv/samba/Finance -p rwxa -k smb_finance_access
-w /srv/samba/Backups -p rwxa -k smb_backups_access
AUDITRULES

systemctl restart auditd

# ─── Log Monitor Script ───────────────────────────────────────────────────────
echo "[*] Installing Samba log watcher..."
cat > /opt/meridian/scripts/smb_log_watcher.py << 'PYEOF'
#!/usr/bin/env python3
"""
Watches Samba logs and writes structured events to the honeypot JSONL log.
Run alongside the main honeypot: python3 smb_log_watcher.py
"""

import json
import re
import time
import os
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

LOG_DIR = "/var/log/samba"
JSONL_OUT = "/app/logs/smb_events.jsonl"

SMB_PATTERNS = [
    (re.compile(r"(\S+)\|(\S+)\|(\S+)\|(\w+)\|ok\|(.+)"), "access"),
    (re.compile(r"authentication for user \[(\S+)\].*from \((\S+)\)"), "auth"),
    (re.compile(r"DENIED\s+(\S+)\s+(\S+)"), "denied"),
]

SENSITIVE_FILES = ["salary", "payroll", "w2", "direct_deposit", "password", "credential", "confidential"]

def parse_and_log(line: str):
    for pattern, event_type in SMB_PATTERNS:
        m = pattern.search(line)
        if m:
            event = {
                "timestamp": datetime.utcnow().isoformat(),
                "event_type": f"smb_{event_type}",
                "raw": line.strip(),
                "groups": m.groups(),
            }
            # Flag sensitive file access
            if any(kw in line.lower() for kw in SENSITIVE_FILES):
                event["high_interest"] = True
                event["reason"] = "Sensitive file accessed"

            with open(JSONL_OUT, "a") as f:
                f.write(json.dumps(event) + "\n")
            break

class SambaLogHandler(FileSystemEventHandler):
    def __init__(self):
        self._pos = {}

    def on_modified(self, event):
        if event.is_directory or not event.src_path.endswith(".log"):
            return
        path = event.src_path
        pos = self._pos.get(path, 0)
        try:
            with open(path, "r", errors="replace") as f:
                f.seek(pos)
                for line in f:
                    parse_and_log(line)
                self._pos[path] = f.tell()
        except Exception as e:
            print(f"Error reading {path}: {e}")

if __name__ == "__main__":
    os.makedirs(os.path.dirname(JSONL_OUT), exist_ok=True)
    print(f"Watching {LOG_DIR} → {JSONL_OUT}")
    handler = SambaLogHandler()
    observer = Observer()
    observer.schedule(handler, LOG_DIR, recursive=False)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
PYEOF

chmod +x /opt/meridian/scripts/smb_log_watcher.py

# ─── Start Samba ──────────────────────────────────────────────────────────────
echo "[*] Starting Samba..."
systemctl enable smbd nmbd
systemctl restart smbd nmbd

echo ""
echo "========================================================"
echo " Samba honeypot ready."
echo ""
echo " Shares available:"
echo "   \\\\$(hostname -I | awk '{print $1}')\\HR"
echo "   \\\\$(hostname -I | awk '{print $1}')\\Finance"
echo "   \\\\$(hostname -I | awk '{print $1}')\\Backups"
echo ""
echo " Log locations:"
echo "   Samba:  /var/log/samba/smb_*.log"
echo "   Audit:  /var/log/audit/audit.log (smb_hr_access, smb_finance_access)"
echo "   JSONL:  /app/logs/smb_events.jsonl (via smb_log_watcher.py)"
echo ""
echo " Start log watcher:"
echo "   python3 /opt/meridian/scripts/smb_log_watcher.py &"
echo ""
echo " Remember: Open ports 139 and 445 in your Azure NSG."
echo "========================================================"

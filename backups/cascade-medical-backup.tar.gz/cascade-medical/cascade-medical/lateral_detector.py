#!/usr/bin/env python3
"""
Lateral Movement Detector — Honeynet Cross-Node Correlation
Runs on BOTH VMs. Watches each node's JSONL log for IPs that appear
on both Meridian HR and Cascade Medical — the signature of lateral movement.

Deploy:
  On Meridian VM:  python3 lateral_detector.py --node meridian --peer-log /mnt/cascade/logs/events.jsonl
  On Cascade VM:   python3 lateral_detector.py --node cascade  --peer-log /mnt/meridian/logs/events.jsonl

Or point peer-log at a shared Azure file share mount that both VMs write to.
Without shared mount: run on each VM independently — each detects movement INTO it from the other.
"""

import argparse
import json
import time
import logging
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s [lateral] %(message)s")
logger = logging.getLogger("lateral")

MY_LOG    = Path("/app/logs/events.jsonl")
ALERT_LOG = Path("/app/logs/lateral_movement.jsonl")
DB_PATH   = Path("/app/data/meridian_honeypot.db")  # same schema on both nodes


def tail_jsonl(path: Path, from_end=True):
    """Yield new lines from a JSONL file as they appear."""
    with open(path, "r", errors="replace") as f:
        if from_end:
            f.seek(0, 2)
        while True:
            line = f.readline()
            if line:
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    pass
            else:
                time.sleep(0.5)


class LateralMovementDetector:
    def __init__(self, my_node: str, peer_log: Path = None):
        self.my_node = my_node
        self.peer_log = peer_log
        # ip -> {node: set of services seen, first_seen, last_seen}
        self.ip_activity: dict = defaultdict(lambda: {
            "meridian": set(), "cascade": set(),
            "first_seen": None, "last_seen": None, "alerted": False
        })
        self._load_existing()

    def _load_existing(self):
        """Load existing sessions from SQLite to seed IP tracking."""
        if not DB_PATH.exists():
            return
        try:
            conn = sqlite3.connect(str(DB_PATH))
            rows = conn.execute("SELECT peer_ip, service, connect_time FROM sessions").fetchall()
            for ip, service, ts in rows:
                self.ip_activity[ip][self.my_node].add(service)
                if not self.ip_activity[ip]["first_seen"]:
                    self.ip_activity[ip]["first_seen"] = ts
            conn.close()
            logger.info(f"Seeded {len(self.ip_activity)} IPs from existing DB")
        except Exception as e:
            logger.warning(f"Could not load existing sessions: {e}")

    def ingest_event(self, event: dict, node: str):
        ip = event.get("ip") or event.get("peer_ip")
        if not ip:
            return
        service = event.get("service", event.get("event_type", "unknown"))
        ts = event.get("timestamp", datetime.utcnow().isoformat())

        state = self.ip_activity[ip]
        state[node].add(service)
        state["last_seen"] = ts
        if not state["first_seen"]:
            state["first_seen"] = ts

        # Check for cross-node activity
        if state["meridian"] and state["cascade"] and not state["alerted"]:
            state["alerted"] = True
            self._alert(ip, state, ts)

    def _alert(self, ip: str, state: dict, ts: str):
        """Fire lateral movement alert."""
        alert = {
            "timestamp": ts,
            "alert_type": "LATERAL_MOVEMENT",
            "severity": "CRITICAL",
            "attacker_ip": ip,
            "meridian_services": list(state["meridian"]),
            "cascade_services": list(state["cascade"]),
            "first_seen": state["first_seen"],
            "description": (
                f"IP {ip} has been active on BOTH honeypot nodes. "
                f"Meridian HR: {sorted(state['meridian'])}. "
                f"Cascade Medical: {sorted(state['cascade'])}. "
                f"This is consistent with lateral movement between network hosts."
            ),
            "mitre": ["T1021 Remote Services", "T1018 Remote System Discovery",
                      "T1570 Lateral Tool Transfer"],
        }

        # Write to alert log
        ALERT_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(ALERT_LOG, "a") as f:
            f.write(json.dumps(alert) + "\n")

        # Console alert
        logger.warning("=" * 70)
        logger.warning("  !! LATERAL MOVEMENT DETECTED !!")
        logger.warning(f"  IP:              {ip}")
        logger.warning(f"  Meridian HR:     {sorted(state['meridian'])}")
        logger.warning(f"  Cascade Medical: {sorted(state['cascade'])}")
        logger.warning(f"  First seen:      {state['first_seen']}")
        logger.warning(f"  MITRE:           T1021, T1018, T1570")
        logger.warning("=" * 70)

    def run_single_node(self):
        """Watch only this node's log — detects when IPs from peer also hit us."""
        logger.info(f"Lateral detector running on {self.my_node} node (single-log mode)")
        logger.info(f"Watching: {MY_LOG}")

        # Load peer IPs from peer log if available
        peer_ips = set()
        if self.peer_log and self.peer_log.exists():
            logger.info(f"Loading peer IPs from {self.peer_log}")
            with open(self.peer_log, "r", errors="replace") as f:
                for line in f:
                    try:
                        e = json.loads(line)
                        ip = e.get("ip") or e.get("peer_ip")
                        if ip:
                            peer_node = "cascade" if self.my_node == "meridian" else "meridian"
                            self.ip_activity[ip][peer_node].add(e.get("event_type", "unknown"))
                            peer_ips.add(ip)
                    except Exception:
                        pass
            logger.info(f"Loaded {len(peer_ips)} IPs from peer node")

        # Now tail our own log
        for event in tail_jsonl(MY_LOG):
            self.ingest_event(event, self.my_node)

    def run_dual_node(self, peer_log: Path):
        """Watch both logs simultaneously using threads."""
        import threading

        def watch_peer():
            peer_node = "cascade" if self.my_node == "meridian" else "meridian"
            logger.info(f"Watching peer log ({peer_node}): {peer_log}")
            for event in tail_jsonl(peer_log, from_end=False):
                self.ingest_event(event, peer_node)

        t = threading.Thread(target=watch_peer, daemon=True)
        t.start()
        self.run_single_node()


def main():
    global MY_LOG
    parser = argparse.ArgumentParser(description="Lateral Movement Detector")
    parser.add_argument("--node", choices=["meridian", "cascade"], required=True,
                        help="Which honeypot node this is running on")
    parser.add_argument("--peer-log", type=Path, default=None,
                        help="Path to peer node's events.jsonl (if accessible)")
    parser.add_argument("--my-log", type=Path, default=MY_LOG,
                        help="Path to this node's events.jsonl")
    args = parser.parse_args()

    MY_LOG = args.my_log

    if not MY_LOG.exists():
        logger.error(f"Log file not found: {MY_LOG}")
        logger.error("Start the honeypot first, then run this detector.")
        return

    detector = LateralMovementDetector(my_node=args.node, peer_log=args.peer_log)

    if args.peer_log and args.peer_log.exists():
        detector.run_dual_node(args.peer_log)
    else:
        logger.info("No peer log provided — running in single-node mode.")
        logger.info("Will detect lateral movement when known peer IPs hit this node.")
        detector.run_single_node()


if __name__ == "__main__":
    main()

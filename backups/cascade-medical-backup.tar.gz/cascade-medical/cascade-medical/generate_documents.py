#!/usr/bin/env python3
"""
Document Generator — Cascade Medical Center
Generates hundreds of realistic-looking hospital documents
across all SMB shares. Run once during setup.
"""

import os
import random
from datetime import datetime, timedelta
from pathlib import Path

BASE = Path("/srv/samba")

# ─── Helpers ──────────────────────────────────────────────────────────────────

def rand_date(start_year=2022, end_year=2024):
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    return (start + timedelta(days=random.randint(0, (end - start).days))).strftime("%Y-%m-%d")

def rand_dob():
    return rand_date(1945, 1995)

def rand_mrn():
    return f"MRN-{random.randint(100000, 999999)}"

def rand_ssn():
    return f"***-**-{random.randint(1000,9999)}"

def rand_phone():
    return f"({random.randint(200,999)}) {random.randint(200,999)}-{random.randint(1000,9999)}"

def rand_npi():
    return str(random.randint(1000000000, 1999999999))

FIRST_NAMES = ["James","Maria","Robert","Linda","Michael","Patricia","William","Barbara",
               "David","Elizabeth","Richard","Jennifer","Joseph","Susan","Thomas","Jessica",
               "Charles","Sarah","Christopher","Karen","Daniel","Lisa","Matthew","Nancy",
               "Anthony","Betty","Mark","Margaret","Donald","Sandra","Steven","Ashley",
               "Paul","Dorothy","Andrew","Kimberly","Joshua","Emily","Kenneth","Donna"]

LAST_NAMES = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis",
              "Rodriguez","Martinez","Hernandez","Lopez","Wilson","Anderson","Thomas",
              "Taylor","Moore","Jackson","Martin","Lee","Perez","Thompson","White",
              "Harris","Sanchez","Clark","Ramirez","Lewis","Robinson","Walker","Young",
              "Allen","King","Wright","Scott","Torres","Nguyen","Hill","Flores","Green"]

DOCTORS = [
    ("Dr. Sarah Chen", "Cardiology", rand_npi()),
    ("Dr. Marcus Webb", "Emergency Medicine", rand_npi()),
    ("Dr. Priya Nair", "Radiology", rand_npi()),
    ("Dr. James Okafor", "Oncology", rand_npi()),
    ("Dr. Elena Vasquez", "Neurology", rand_npi()),
    ("Dr. Kevin Park", "Orthopedics", rand_npi()),
    ("Dr. Amanda Reyes", "Pediatrics", rand_npi()),
    ("Dr. Thomas Brennan", "Psychiatry", rand_npi()),
    ("Dr. Fatima Al-Hassan", "Infectious Disease", rand_npi()),
    ("Dr. William Cho", "Surgery", rand_npi()),
]

MEDICATIONS = ["Metformin 500mg","Lisinopril 10mg","Atorvastatin 20mg","Omeprazole 20mg",
               "Levothyroxine 50mcg","Amlodipine 5mg","Metoprolol 25mg","Losartan 50mg",
               "Albuterol inhaler","Gabapentin 300mg","Sertraline 50mg","Hydrochlorothiazide 25mg",
               "Pantoprazole 40mg","Montelukast 10mg","Furosemide 40mg","Warfarin 5mg",
               "Insulin glargine 100u/mL","Prednisone 10mg","Tramadol 50mg","Amoxicillin 500mg"]

DIAGNOSES = ["Type 2 Diabetes Mellitus","Hypertension","Coronary Artery Disease",
             "COPD","Acute Myocardial Infarction","Pneumonia","Sepsis","Stroke (CVA)",
             "Congestive Heart Failure","Atrial Fibrillation","Appendicitis","Fracture",
             "Urinary Tract Infection","Depression","Anxiety Disorder","Migraine",
             "Rheumatoid Arthritis","Osteoporosis","Kidney Disease (CKD Stage 3)",
             "Asthma","Hypothyroidism","Hyperlipidemia","Obesity (BMI 34.2)","GERD"]

ICD_CODES = {"Type 2 Diabetes Mellitus":"E11.9","Hypertension":"I10","Coronary Artery Disease":"I25.10",
             "COPD":"J44.1","Acute Myocardial Infarction":"I21.9","Pneumonia":"J18.9",
             "Sepsis":"A41.9","Stroke (CVA)":"I63.9","Congestive Heart Failure":"I50.9",
             "Atrial Fibrillation":"I48.91","Appendicitis":"K37","Fracture":"S72.001A"}

def patient_name():
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"

def doctor():
    return random.choice(DOCTORS)

def write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)

# ─── Clinical Share ────────────────────────────────────────────────────────────

def gen_clinical():
    share = BASE / "Clinical"

    # Patient records
    (share / "Patient_Records").mkdir(parents=True, exist_ok=True)
    for i in range(60):
        name = patient_name()
        mrn = rand_mrn()
        dob = rand_dob()
        dx = random.choice(DIAGNOSES)
        dr, dept, npi = doctor()
        meds = random.sample(MEDICATIONS, random.randint(2, 5))
        allergies = random.choice(["NKDA", "Penicillin", "Sulfa", "Aspirin", "Latex", "Codeine"])
        admit = rand_date(2023, 2024)
        icd = ICD_CODES.get(dx, f"Z{random.randint(10,99)}.{random.randint(0,9)}")

        content = f"""CASCADE MEDICAL CENTER
PATIENT MEDICAL RECORD
{'='*50}

PATIENT INFORMATION
  Name:           {name}
  MRN:            {mrn}
  Date of Birth:  {dob}
  SSN:            {rand_ssn()}
  Phone:          {rand_phone()}
  Insurance ID:   INS-{random.randint(10000000,99999999)}
  Insurance:      {random.choice(['BlueCross BlueShield','Aetna','UnitedHealth','Cigna','Medicare','Medicaid'])}

ADMISSION
  Date:           {admit}
  Attending:      {dr} (NPI: {npi})
  Department:     {dept}
  Room:           {random.randint(100,450)}{random.choice(['A','B',''])}

PRIMARY DIAGNOSIS
  {dx}
  ICD-10: {icd}

ALLERGIES: {allergies}

CURRENT MEDICATIONS
{chr(10).join(f'  - {m}' for m in meds)}

VITALS (Admission)
  BP:     {random.randint(100,160)}/{random.randint(60,100)} mmHg
  HR:     {random.randint(55,110)} bpm
  Temp:   {round(random.uniform(97.2, 101.4), 1)}°F
  SpO2:   {random.randint(92,100)}%
  Weight: {random.randint(110,280)} lbs

ATTENDING NOTES
Patient presents with {dx.lower()}. History reviewed.
Treatment plan discussed with patient and family.
Follow-up scheduled in {random.randint(2,12)} weeks.

Signed: {dr}
Date:   {admit}
"""
        write(share / "Patient_Records" / f"{mrn}_{name.replace(' ','_')}.txt", content)

    # Discharge summaries
    (share / "Discharge_Summaries").mkdir(parents=True, exist_ok=True)
    for i in range(40):
        name = patient_name()
        mrn = rand_mrn()
        admit = rand_date(2023, 2024)
        discharge = (datetime.strptime(admit, "%Y-%m-%d") + timedelta(days=random.randint(1,14))).strftime("%Y-%m-%d")
        dx = random.choice(DIAGNOSES)
        dr, dept, _ = doctor()
        content = f"""CASCADE MEDICAL CENTER — DISCHARGE SUMMARY

Patient:    {name}  |  MRN: {mrn}
Admission:  {admit}  |  Discharge: {discharge}
Attending:  {dr}  |  Unit: {dept}

PRINCIPAL DIAGNOSIS: {dx}

HOSPITAL COURSE:
Patient admitted with {dx.lower()}. Treated appropriately per protocol.
Condition improved. Patient discharged in stable condition.

DISCHARGE MEDICATIONS:
{chr(10).join(f'  {j+1}. {m}' for j, m in enumerate(random.sample(MEDICATIONS, 3)))}

FOLLOW-UP: {dr} in {random.randint(1,4)} weeks
RESTRICTIONS: {random.choice(['No restrictions','No heavy lifting x4 weeks','Low sodium diet','Bedrest x1 week'])}

Electronically signed: {dr}  |  {discharge}
"""
        write(share / "Discharge_Summaries" / f"DS_{mrn}_{discharge}.txt", content)

    # Clinical protocols
    protocols = {
        "Sepsis_Bundle_Protocol.txt": """CASCADE MEDICAL CENTER — SEPSIS BUNDLE PROTOCOL (SEP-1)
Hour-1 Bundle:
  1. Obtain blood cultures (x2) before antibiotics
  2. Administer broad-spectrum antibiotics within 1 hour
  3. Measure lactate — if >2 mmol/L: resuscitate
  4. Begin 30mL/kg crystalloid for hypotension or lactate >=4
  5. Apply vasopressors if MAP <65 mmHg despite fluids

Antibiotic Selection:
  Community-acquired: Piperacillin-Tazobactam 3.375g IV q6h
  Hospital-acquired:  Vancomycin 25mg/kg + Meropenem 1g IV q8h
  Immunocompromised:  Cefepime 2g IV q8h + Antifungal coverage

Reassess at 6 hours. Document in EMR under Sepsis Flowsheet.
Authorization: Dr. Fatima Al-Hassan, Infectious Disease""",

        "Code_Blue_Procedure.txt": """CASCADE MEDICAL CENTER — CODE BLUE PROCEDURE
Activate: Dial 5555 | Announce overhead: "Code Blue, [Location]"

Response Team:
  - Charge RN (team leader)
  - Resident physician
  - RT (airway)
  - Pharmacist
  - Code cart RN

CPR: 30:2 ratio, rotate compressors q2 min, 100-120/min
Defibrillation: 200J biphasic (VF/pVT)
Epinephrine: 1mg IV/IO q3-5 min
Amiodarone: 300mg IV bolus (first dose)

Post-ROSC: 12-lead ECG, targeted temp management if indicated
Document in EMR. Debrief within 24h.""",

        "Medication_Administration_Policy.txt": """MEDICATION ADMINISTRATION POLICY — CMC-PHARM-001

Five Rights: Right Patient, Right Drug, Right Dose, Right Route, Right Time
Two-patient identifier required before ALL medication administration.

High-Alert Medications (double-check required):
  - Insulin (all types)
  - Anticoagulants (Heparin, Warfarin, DOACs)
  - Concentrated electrolytes (KCl, NaCl >0.9%)
  - Opioids (morphine, hydromorphone, fentanyl)
  - Chemotherapy agents

Override policy: Emergency overrides require charge RN + MD co-sign within 1 hour.
Pyxis access: badge + PIN. Report discrepancies to pharmacy immediately.
Contact: pharmacy-hotline@cascademedical.internal ext. 4000""",
    }
    for fname, content in protocols.items():
        write(share / "Protocols" / fname, content)

    # Lab results
    (share / "Lab_Results").mkdir(parents=True, exist_ok=True)
    for i in range(35):
        name = patient_name()
        mrn = rand_mrn()
        date = rand_date(2023, 2024)
        content = f"""CASCADE MEDICAL CENTER — LABORATORY REPORT
Patient: {name}  |  MRN: {mrn}  |  Collected: {date}

COMPLETE METABOLIC PANEL
  Glucose:      {random.randint(70,280)} mg/dL    [70-100]
  BUN:          {random.randint(8,40)} mg/dL      [8-20]
  Creatinine:   {round(random.uniform(0.5,3.2),1)} mg/dL   [0.6-1.2]
  eGFR:         {random.randint(20,120)} mL/min
  Sodium:       {random.randint(132,148)} mEq/L   [136-145]
  Potassium:    {round(random.uniform(3.0,5.8),1)} mEq/L   [3.5-5.0]
  CO2:          {random.randint(18,32)} mEq/L     [22-29]

CBC WITH DIFFERENTIAL
  WBC:          {round(random.uniform(2.5,18.0),1)} K/uL   [4.5-11.0]
  RBC:          {round(random.uniform(3.0,5.5),2)} M/uL   [4.5-5.5]
  Hemoglobin:   {round(random.uniform(7.0,16.5),1)} g/dL  [12.0-17.5]
  Hematocrit:   {random.randint(22,52)}%          [37-52]
  Platelets:    {random.randint(50,450)} K/uL     [150-400]

Resulted by: AutoAnalyzer v4.2 | Verified: Lab Tech ID #{random.randint(1000,9999)}
"""
        write(share / "Lab_Results" / f"LAB_{mrn}_{date}.txt", content)

# ─── Radiology Share ───────────────────────────────────────────────────────────

def gen_radiology():
    share = BASE / "Radiology"

    modalities = ["CT","MRI","X-Ray","Ultrasound","PET","Mammography","Fluoroscopy"]
    body_parts = ["Chest","Abdomen","Head","Pelvis","Spine (L-S)","Knee","Shoulder",
                  "Abdomen/Pelvis","Brain w/ contrast","Chest w/ contrast","Neck"]
    findings = [
        "No acute cardiopulmonary process. Mild cardiomegaly noted.",
        "No acute intracranial abnormality. Stable chronic changes.",
        "Consolidation right lower lobe consistent with pneumonia.",
        "No PE identified. Mild pleural effusion bilateral.",
        "Diffuse osteopenia. No acute fracture.",
        "Heterogeneous hepatic lesion 2.3cm — recommend follow-up MRI.",
        "Normal study. No significant abnormality identified.",
        "Moderate degenerative changes lumbar spine. Disc protrusion L4-L5.",
        "Pulmonary nodule 8mm RUL — recommend 3-month follow-up CT.",
        "No acute osseous abnormality. Soft tissue swelling noted.",
    ]

    (share / "Reports").mkdir(parents=True, exist_ok=True)
    for i in range(55):
        name = patient_name()
        mrn = rand_mrn()
        date = rand_date(2023, 2024)
        mod = random.choice(modalities)
        body = random.choice(body_parts)
        dr, _, _ = doctor()
        content = f"""CASCADE MEDICAL CENTER — RADIOLOGY REPORT

PATIENT:    {name}
MRN:        {mrn}
DOB:        {rand_dob()}
DATE:       {date}
ACCESSION:  ACC-{random.randint(1000000,9999999)}

EXAMINATION: {mod} {body}
INDICATION:  {random.choice(DIAGNOSES)}
TECHNIQUE:   Standard {mod} protocol. {random.choice(['IV contrast administered.','No contrast.','Oral contrast administered.',''])}

COMPARISON: {random.choice(['Prior study {}'.format(rand_date(2021,2022)),'No prior available','CT chest {}'.format(rand_date(2022,2023))])}

FINDINGS:
{random.choice(findings)}

{'Additional finding: Small pericardial effusion. Clinical correlation recommended.' if random.random() < 0.2 else ''}

IMPRESSION:
{random.choice(findings)}

Electronically signed: {dr}
Date/Time: {date} {random.randint(7,18):02d}:{random.randint(0,59):02d}
"""
        write(share / "Reports" / f"RAD_{mrn}_{date}_{mod.replace('/','')}.txt", content)

    # PACS system credentials (bait)
    write(share / "PACS_System_Info.txt", """CASCADE MEDICAL CENTER — PACS ACCESS INFORMATION
Radiology Information System: Merge PACS v7.4

PACS Server:     pacs-prod.cascademedical.internal
DICOM Port:      104
Web Portal:      http://pacs-prod.cascademedical.internal:8080/merge

Service Account: svc_pacs
Password:        P@cs_Casc4de2024!

HL7 Interface:   hl7-bridge.cascademedical.internal:2575
HL7 Auth:        hl7svc / HL7_Casc@de!

Note: PACS maintenance window Sunday 02:00-04:00 UTC
Contact: radiology-it@cascademedical.internal""")

    # Equipment inventory
    equipment = ["GE Revolution CT Scanner - SN CT-4821-GE","Siemens Magnetom MRI 3T - SN MRI-2291-SIE",
                 "Philips Azurion Fluoroscopy - SN FL-8847-PHI","Hologic Selenia Mammography - SN MM-3312-HOL",
                 "GE Logiq E10 Ultrasound x3 - SN US-1104/1105/1106"]
    write(share / "Equipment" / "Equipment_Inventory.txt",
          "CASCADE RADIOLOGY — EQUIPMENT INVENTORY\n\n" +
          "\n".join(f"  {e}" for e in equipment) +
          "\n\nService contact: biomedical@cascademedical.internal\nAdmin password: BioMed@2024!")

# ─── Pharmacy Share ────────────────────────────────────────────────────────────

def gen_pharmacy():
    share = BASE / "Pharmacy"

    # Controlled substance logs
    (share / "Controlled_Substances").mkdir(parents=True, exist_ok=True)
    cs_drugs = [("Oxycodone HCl 5mg","Schedule II","DEA-Cx-4821"),
                ("Hydromorphone 2mg/mL","Schedule II","DEA-Cx-4822"),
                ("Fentanyl 25mcg patch","Schedule II","DEA-Cx-4823"),
                ("Lorazepam 1mg","Schedule IV","DEA-Cx-4830"),
                ("Alprazolam 0.5mg","Schedule IV","DEA-Cx-4831"),
                ("Zolpidem 10mg","Schedule IV","DEA-Cx-4832"),
                ("Tramadol 50mg","Schedule IV","DEA-Cx-4833")]

    for month in range(1, 7):
        content = f"CASCADE MEDICAL CENTER — CONTROLLED SUBSTANCE LOG\nMonth: 2024-{month:02d}\n\n"
        content += f"{'Drug':<30}{'Schedule':<15}{'DEA#':<15}{'Dispensed':<12}{'Wasted':<10}{'Balance'}\n"
        content += "-"*85 + "\n"
        for drug, sched, dea in cs_drugs:
            dispensed = random.randint(50, 400)
            wasted = random.randint(2, 30)
            balance = random.randint(10, 200)
            content += f"{drug:<30}{sched:<15}{dea:<15}{dispensed:<12}{wasted:<10}{balance}\n"
        content += f"\nPharmacist: {random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}, PharmD\n"
        content += f"DEA License: {random.randint(10000000,99999999)}\n"
        write(share / "Controlled_Substances" / f"CS_Log_2024_{month:02d}.txt", content)

    # Drug formulary
    write(share / "Formulary" / "Hospital_Formulary_2024.txt",
          "CASCADE MEDICAL CENTER — APPROVED DRUG FORMULARY 2024\n\n" +
          "\n".join(f"  {m}" for m in MEDICATIONS) +
          "\n\nFormulary questions: pharmacy@cascademedical.internal\nPyxis admin: pyxis_admin / Pyx1s@CMC2024!")

    # Pyxis overrides (bait — these look like real system creds)
    write(share / "Admin" / "Pyxis_Override_Codes.txt", """CASCADE PHARMACY — PYXIS OVERRIDE REFERENCE
FOR AUTHORIZED PHARMACY STAFF ONLY

Emergency override code: 8821-PHARM
Supervisor override: SUP-4481-CMC

Pyxis server: pyxis-prod.cascademedical.internal
Admin console: https://pyxis-prod.cascademedical.internal:8443
Admin user:    pyxis_admin
Admin pass:    Pyx1s@CMC2024!

Backup access: pharmacy manager badge + PIN 4481

Contact: Robert Chen, Director of Pharmacy
         r.chen@cascademedical.internal | Ext. 4000""")

    # 30 medication order sheets
    (share / "Medication_Orders").mkdir(parents=True, exist_ok=True)
    for i in range(30):
        name = patient_name()
        mrn = rand_mrn()
        dr, dept, _ = doctor()
        date = rand_date(2023, 2024)
        meds = random.sample(MEDICATIONS, random.randint(3, 6))
        content = f"""CASCADE MEDICAL CENTER — PHYSICIAN MEDICATION ORDER

Patient:  {name}  |  MRN: {mrn}  |  Date: {date}
Ordering: {dr}  |  Dept: {dept}
Allergies: {random.choice(['NKDA','Penicillin','Sulfa','Aspirin'])}
Weight:   {random.randint(50,130)} kg

ORDERS:
"""
        for med in meds:
            content += f"  ☐ {med} — {random.choice(['PO daily','IV q8h','PO BID','SQ daily','IV PRN q4h'])} x {random.randint(3,14)} days\n"
        content += f"\nVerified by: Pharmacist on duty\nTime: {random.randint(0,23):02d}:{random.randint(0,59):02d}\n"
        write(share / "Medication_Orders" / f"MedOrder_{mrn}_{date}.txt", content)

# ─── Admin Share ───────────────────────────────────────────────────────────────

def gen_admin():
    share = BASE / "Admin"

    # Staff directory
    staff = []
    roles = ["RN","LPN","CNA","MD","NP","PA","PharmD","RT","PT","OT","Social Worker","Case Manager"]
    depts = ["ED","ICU","Med/Surg","Cardiology","Radiology","Pharmacy","OR","Pediatrics","Oncology","Psychiatry"]
    for i in range(80):
        name = patient_name()
        role = random.choice(roles)
        dept = random.choice(depts)
        ext = random.randint(4000, 4999)
        badge = f"CMC-{random.randint(10000,99999)}"
        staff.append(f"  {name:<28}{role:<12}{dept:<18}Ext.{ext}  Badge:{badge}")

    write(share / "Staff_Directory_2024.txt",
          "CASCADE MEDICAL CENTER — STAFF DIRECTORY 2024\n" + "="*75 + "\n" +
          f"  {'Name':<28}{'Role':<12}{'Department':<18}{'Contact'}\n" + "-"*75 + "\n" +
          "\n".join(staff))

    # IT credentials (high-value bait)
    write(share / "IT_Access" / "System_Credentials_CONFIDENTIAL.txt", """CASCADE MEDICAL CENTER — IT SYSTEM ACCESS REFERENCE
CONFIDENTIAL — IT DEPARTMENT USE ONLY

EMR System (Epic):
  URL:      https://emr.cascademedical.internal
  Admin:    epic_admin / Ep1c@CMC_Pr0d!
  DB:       epic_db_admin / Epic_DB_2024!

Active Directory:
  Domain:   CASCADEMEDICAL.LOCAL
  DC:       dc01.cascademedical.internal
  Bind DN:  CN=svc_ldap,OU=Service,DC=cascademedical,DC=local
  Password: LDAP_Casc@de2024!

VPN Gateway:
  Server:   vpn.cascademedical.internal
  Protocol: Fortinet SSL-VPN
  Admin:    vpnadmin / VPN@Casc4de!

Backup System (Veeam):
  Server:   backup01.cascademedical.internal
  User:     veeam_admin / Ve3am@Backup!

SFTP (Insurance exchange):
  Host:     sftp.cascademedical.internal
  User:     sftp_claims / ClaimsXfer@2024!

Last updated: 2024-05-15 by Kevin Park, IT Director
kevin.park@cascademedical.internal | Ext. 4481""")

    # Budget documents
    write(share / "Finance" / "FY2024_IT_Budget.txt", """CASCADE MEDICAL CENTER — FY2024 IT BUDGET

Total IT Budget: $4,281,000

  EMR Licensing (Epic):          $1,200,000
  Infrastructure/Azure:           $480,000
  Security (CrowdStrike, SIEM):   $320,000
  Network/Telecom:                $210,000
  Helpdesk Staff (8 FTE):         $640,000
  Cybersecurity Training:          $45,000
  DR/Backup:                      $180,000
  Medical Devices/IoT:            $420,000
  Contingency (10%):              $428,000
  Software Licenses:              $358,000

Contact: CFO Sarah Mitchell | s.mitchell@cascademedical.internal""")

    # Policies
    policies = {
        "HIPAA_Breach_Response_Policy.txt": """HIPAA BREACH RESPONSE POLICY — CMC-PRIV-001
Upon discovery of potential PHI breach:
  1. Immediately notify Privacy Officer (p.officer@cascademedical.internal)
  2. Preserve all evidence — do NOT delete logs
  3. Isolate affected systems (contact IT Security: security@cascademedical.internal)
  4. Document timeline within 1 hour of discovery
  5. HHS notification required within 60 days if >500 individuals affected
  6. Patient notification within 60 days

Privacy Officer: Jennifer Walsh | Ext. 4200
IT Security: security@cascademedical.internal | Ext. 4481 (24/7)""",

        "Remote_Access_Policy.txt": """REMOTE ACCESS POLICY — CMC-IT-004
Approved remote access methods:
  1. Fortinet VPN (staff) — vpn.cascademedical.internal
  2. Citrix Virtual Desktop (clinical) — citrix.cascademedical.internal
  3. Epic Haiku/Canto (mobile) — MFA required

VPN credentials: AD username + password + MFA token
Default MFA: Microsoft Authenticator app
IT Helpdesk: helpdesk@cascademedical.internal | Ext. 4HELP (4435)
Emergency IT access: IT manager badge + PIN 8821""",
    }
    for fname, content in policies.items():
        write(share / "Policies" / fname, content)

    # Contracts
    for vendor in ["Epic Systems","Siemens Healthineers","Philips Healthcare","Cerner","3M Health"]:
        write(share / "Contracts" / f"Vendor_{vendor.replace(' ','_')}_2024.txt",
              f"VENDOR CONTRACT — {vendor.upper()}\nCascade Medical Center\nContract period: 2024-01-01 to 2024-12-31\n"
              f"Value: ${random.randint(100,900):,}000\nContact: contracts@cascademedical.internal\n"
              f"Renewal: Auto-renews unless 90-day notice given\nSigned: CEO Mark Henderson")

# ─── Research Share ────────────────────────────────────────────────────────────

def gen_research():
    share = BASE / "Research"

    studies = [
        ("ONCO-2024-01", "Efficacy of Novel CAR-T Therapy in Relapsed B-Cell Lymphoma", "Oncology"),
        ("CARD-2024-03", "Remote Monitoring in CHF Patients Post-Discharge", "Cardiology"),
        ("NEUR-2024-02", "Early Intervention in Mild Cognitive Impairment", "Neurology"),
        ("INFX-2024-01", "Antimicrobial Stewardship Outcomes in ICU Sepsis", "Infectious Disease"),
        ("PEDS-2024-02", "RSV Prophylaxis in High-Risk Neonates", "Pediatrics"),
    ]

    for study_id, title, dept in studies:
        (share / study_id).mkdir(parents=True, exist_ok=True)
        dr, _, _ = doctor()

        # Protocol
        write(share / study_id / "Protocol.txt",
              f"IRB APPROVED CLINICAL STUDY PROTOCOL\n\nStudy ID: {study_id}\nTitle: {title}\n"
              f"Department: {dept}\nPI: {dr}\nIRB#: IRB-CMC-{random.randint(1000,9999)}\n"
              f"Status: ACTIVE\nEnrollment target: {random.randint(50,500)} participants\n"
              f"Sponsor: NIH Grant #{random.randint(1000000,9999999)}\n\n"
              f"Inclusion: Adults 18-80, {random.choice(DIAGNOSES)}\n"
              f"Exclusion: Pregnancy, renal failure, contraindicated medications\n")

        # De-identified patient data (still bait)
        write(share / study_id / "Enrolled_Subjects_DEIDENTIFIED.csv",
              "Subject_ID,Age,Sex,Race,Diagnosis,Enrollment_Date,Status\n" +
              "\n".join(f"SUB-{random.randint(1000,9999)},{random.randint(18,80)},"
                        f"{random.choice(['M','F'])},{random.choice(['White','Hispanic','Black','Asian','Other'])},"
                        f"{random.choice(DIAGNOSES)},{rand_date(2023,2024)},{random.choice(['Active','Withdrawn','Completed'])}"
                        for _ in range(random.randint(20, 60))))

    # Biosafety
    write(share / "Biosafety" / "BSL2_Lab_Access_Codes.txt",
          "CASCADE MEDICAL — BSL-2 LAB ACCESS\nKeypad code: 8821\nAfter-hours: badge + 4481\n"
          "Lab manager: Dr. Priya Nair | p.nair@cascademedical.internal\n"
          "Incident reporting: biosafety@cascademedical.internal")

# ─── Backups Share ─────────────────────────────────────────────────────────────

def gen_backups():
    share = BASE / "Backups"

    # Fake backup files
    for date_offset in range(30):
        date = (datetime(2024, 6, 3) - timedelta(days=date_offset)).strftime("%Y%m%d")
        for name in [f"epic_emr_db_{date}.sql.gz", f"cascade_hr_{date}.sql.gz"]:
            (share / name).touch()

    # Backup runbook with credentials
    write(share / "Backup_Runbook.txt", """CASCADE MEDICAL CENTER — BACKUP RUNBOOK

Schedule: Nightly 02:00 UTC — Veeam Backup & Replication
Retention: 30 daily, 12 weekly, 12 monthly

Systems backed up:
  1. Epic EMR database (epic-db-prod.cascademedical.internal)
  2. PACS image archive (pacs-prod.cascademedical.internal)
  3. Active Directory (dc01.cascademedical.internal)
  4. File servers (fs01.cascademedical.internal)

Veeam console: https://backup01.cascademedical.internal:9443
Username: veeam_admin
Password: Ve3am@Backup!

Restore procedure:
  1. Log into Veeam console
  2. Select restore point
  3. Verify checksum before restore
  4. Notify change management: change@cascademedical.internal

DR site: cascademedical-dr.azurewebsites.net
DR failover: contact IT Director Kevin Park (Ext. 4481)""")

# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("[*] Generating Cascade Medical Center document corpus...")
    gen_clinical()
    print("  [+] Clinical share — 135+ documents")
    gen_radiology()
    print("  [+] Radiology share — 60+ documents")
    gen_pharmacy()
    print("  [+] Pharmacy share — 50+ documents")
    gen_admin()
    print("  [+] Admin share — 40+ documents")
    gen_research()
    print("  [+] Research share — 30+ documents")
    gen_backups()
    print("  [+] Backups share — 30+ files")

    # Count total
    total = sum(1 for _ in BASE.rglob("*") if _.is_file())
    print(f"\n[✓] Generated {total} files across all shares")
    print(f"    Location: {BASE}")
